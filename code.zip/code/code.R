####rarefy####
library(vegan)
Bfn1<-read.csv("otutab_raw_16S.csv", header=TRUE, row.names=1)
Bfn<-t(Bfn1)
S1 <- specnumber(Bfn)
(raremax1 <- min(rowSums(Bfn)))
newOTU1 <- rrarefy(Bfn, raremax1)
newOTU<-t(newOTU1)
write.csv(newOTU,file='16S_rarefy.csv')



########################### niche
#####CP-NP-MM——Difference test####
otu <- read.csv("ado_s1_16s.csv", header=TRUE, row.names = 1)
otu <- otu[which(rowSums(otu) > 0), ]
  
write.csv(otu,file = "remv01.csv")
  
#####################   kw_test
x <- read.csv("remv01.csv", header=TRUE, row.names=1)
design <- read.csv("GROUP_s1_16s.csv", header=TRUE, row.names=1)
  
data4 <- c()
  
for(i in 1:nrow(x))
  {
    ab<-as.numeric(x[i,1:12])
    b<-design$g
    aa<-data.frame(ab,b)
    y1=kruskal.test(ab~b,data=aa)
    y2=y1[["p.value"]]
    data4<-rbind(data4,y2)
  }
  
row.names(data4)<-row.names(x)
write.csv(data4, "p1.csv")



#####(Fig. 1)niche overlap & width####
#----------------------------------significant
library(spaa)
ado <- read.csv("s1_p_sig_16s.csv", header=TRUE, row.names=1)
ado1 <- t(ado)
niche_overlap <- niche.overlap(ado1, method = 'levins')
niche_overlap <- as.matrix(niche_overlap)
  
# niche_width <- niche.width(ado1, method = 'levins')
# niche_width1 <- t(niche_width)
  
write.table(niche_overlap, 'niche_overlap_16s_s1_sig.txt', sep = '\t', col.names = NA, quote = FALSE)
  
#--------------------------------insignificant
ado <- read.csv("s1_p_insig_16s.csv", header=TRUE, row.names=1)
ado1 <- t(ado)
niche_overlap <- niche.overlap(ado1, method = 'levins')
niche_overlap <- as.matrix(niche_overlap)
write.table(niche_overlap, 'niche_overlap_16s_s1_insig.txt', sep = '\t', col.names = NA, quote = FALSE)


#------------------------------------------------------Format conversion, width to length
library(vegan)
library(reshape)
ado <- read.delim('niche_overlap_16s_s1_sig.txt', row.name = 1, check.names = FALSE)
  
ado1 <- melt(as.matrix(ado)) #Converting the dist object to matrix using melt
p2    <- t(apply(ado1[,c(1,2)],1,FUN=sort))
rmv12 <- which(p2[,1] == p2[,2])
rmv12
p.new1    <- paste(p2[,1],p2[,2],sep="|")
p.new1
rmv22 <- which(duplicated(p.new1))
rmv22
long   <- ado1[-c(rmv12,rmv22),] 
  
write.csv(long, file = "long_overlap_16s_s1_sig.csv")
  
############################### insig
ado <- read.delim('niche_overlap_16s_s1_insig.txt', row.name = 1, check.names = FALSE)
  
ado1 <- melt(as.matrix(ado)) #Converting the dist object to matrix using melt
p2    <- t(apply(ado1[,c(1,2)],1,FUN=sort))
rmv12 <- which(p2[,1] == p2[,2])
rmv12
p.new1    <- paste(p2[,1],p2[,2],sep="|")
p.new1
rmv22 <- which(duplicated(p.new1))
rmv22
long   <- ado1[-c(rmv12,rmv22),] 
  
write.csv(long, file = "long_overlap_16s_s1_insig.csv")



#-------------------------------------------------------------S1_bind
f <- read.csv("long_overlap_16s_s1_sig.csv", header = TRUE, row.names = 1)
n <- read.csv("long_overlap_16s_s1_insig.csv", header = TRUE, row.names = 1)
  
a <- rep("Significant", 211575)
b <- rep("Insignificant", 66084756)
e <- rep("S1", 66296331)
  
c <- cbind(f, a)
d <- cbind(n, b)
  
names(c)[4]<-'Group'
names(d)[4]<-'Group'
  
s1 <- rbind(c, d)
s1 <- cbind(s1, e)
  names(s1)[5]<-'site'
  
write.csv(s1,file = "s1.csv",row.names = T)


#-------------------------------------------------------------plot_bind
  s1 <-read.csv("s1.csv", header=TRUE)
  s2 <-read.csv("s2.csv", header=TRUE)
  s3 <-read.csv("s3.csv", header=TRUE)
  s4 <-read.csv("s4.csv", header=TRUE)
  s5 <-read.csv("s5.csv", header=TRUE)
  s6 <-read.csv("s6.csv", header=TRUE)
  
  ado <- rbind(s1, s2, s3, s4, s5, s6)
  write.csv(ado,file = "s1-6.csv",row.names = F)
  
  library(ggpubr)
  phi<-read.csv("s1-6.csv", header=TRUE)
  
  compare_means(value~Group, data=phi, group.by = "site",method = "wilcox.test")
  library(ggplot2)
  phi$Group <- factor(phi$Group,levels=c("Significant","Insignificant"))
  
  p2 <- ggbarplot(phi, x="site", y="value", add = "mean_se",color = "black",fill = "Group",ylim = c(0, 0.72),  ##fill函数表示填充柱子的颜色,color表示误差线和柱子边框的颜色
                  palette = c("#FB9A99","#33A02C"), position = position_dodge(0.8))+
    stat_compare_means(aes(group=Group), label = "p.signif", label.y = 0.7, size = 10)+
    scale_y_continuous(name= expression(Niche ~ overlap ~ index))+##设置y轴标题
    scale_x_discrete(name= expression(Sites))+
    theme(panel.background = element_rect(fill = "transparent", colour = "black"))+ #添加黑色外框
    theme(axis.text.y  = element_text(size = 20,color="black"))+##设置y轴刻度上的字体大小
    theme(axis.title.y = element_text(size = 20, color="black"))+#设置Y轴标题大小
    theme(axis.title.x = element_text(size = 20, color="black"))+#设置x轴标题大小
    theme(legend.text=element_text(size=20, color="black"))+#图例字体大小
    theme(axis.text.x = element_text(size = 20,color="black",vjust = 1.0, hjust = 0.55))+ ##设置X轴刻度上的字体大小
    guides(fill=guide_legend(title=NULL))
  
p2
ggsave('CP-MM-NP_nicheoverlap.pdf', p2, width = 7, height = 5.5)
  
  
  

####(Fig. 1)PCoA_16S######
# Load necessary packages
library(vegan)
library(ggplot2)
library(dplyr)
library(multcompView)

# Read OTU table data
otu_table <- read.csv("ado_All.csv", row.names = 1)

# Read metadata
metadata <- read.csv("group.csv")

# Calculate distance matrix using Bray-Curtis distance
distance_matrix <- vegdist(t(otu_table), method = "bray")

# Perform Principal Coordinate Analysis (PCoA), set eig = TRUE to return eigenvalues
pcoa_result <- cmdscale(distance_matrix, k = 2, eig = TRUE)

# Extract eigenvalues
eigenvalues <- pcoa_result$eig
print(eigenvalues)

# Calculate explained variance
explained_var_x <- eigenvalues[1] / sum(eigenvalues) * 100
explained_var_y <- eigenvalues[2] / sum(eigenvalues) * 100

# Create explained variance table
explained_var_table <- data.frame(
  Axis = c("PCoA1", "PCoA2"),
  Explained_Variance = c(explained_var_x, explained_var_y)
)

# Output explained variance table
print(explained_var_table)

# Optionally save the table as a CSV file
write.csv(explained_var_table, "pcoa_explained_variance.csv", row.names = FALSE)

# Extract PCoA scores
if (is.matrix(pcoa_result$points) || is.data.frame(pcoa_result$points)) {
  scores_df <- data.frame(PCoA1 = pcoa_result$points[, 1], PCoA2 = pcoa_result$points[, 2], metadata)
} else {
  stop("PCoA results are not a matrix or data frame; please check data and function calls.")
}

# Ensure Sites and Treatments are factor types
scores_df$Sites <- as.factor(scores_df$Sites)
scores_df$Treatments <- as.factor(scores_df$Treatments)

# Calculate centroids and standard deviations for each site and treatment
centroids <- scores_df %>%
  group_by(Sites, Treatments) %>%
  summarise(PCoA1_mean = mean(PCoA1), PCoA2_mean = mean(PCoA2),
            PCoA1_sd = sd(PCoA1), PCoA2_sd = sd(PCoA2))

# Custom colors and shapes
Treatments_colors <- c("MC-I" = "#f8caaa", "CP-I" = "#f09694", "MM-I" = "#a3c9dc", "NP-I" = "#acd16b", "MN-I" = "#89cbbf")
Sites_shapes <- c("S1" = 15, "S2" = 16, "S3" = 17, "S4" = 0, "S5" = 18, "S6" = 20)

# Adjust error bar thickness, set to 1 here
errorbar_size <- 0.5

# Plot centroids with error bars, using colors to distinguish treatments and shapes for sites
p1 <- ggplot(centroids, aes(x = PCoA1_mean, y = PCoA2_mean, color = Treatments, shape = Sites)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = PCoA2_mean - PCoA2_sd, ymax = PCoA2_mean + PCoA2_sd), width = 0.02) +
  geom_errorbarh(aes(xmin = PCoA1_mean - PCoA1_sd, xmax = PCoA1_mean + PCoA1_sd), height = 0.02) +
  scale_color_manual(values = Treatments_colors) +
  scale_shape_manual(values = Sites_shapes) +
  labs(x = paste0("PCoA1 (", round(explained_var_x, 2), "%)"), 
       y = paste0("PCoA2 (", round(explained_var_y, 2), "%)"), 
       title = "(a) Prokaryotes") +
  theme_minimal()

# Add background ellipses for samples from the same site
p <- p1 + stat_ellipse(data = scores_df, aes(x = PCoA1, y = PCoA2, group = Sites, color = Sites), 
                       level = 0.95, linetype = 2, alpha = 0.2)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black", face = "plain"),
  axis.title.y = element_text(size = 12, color = "black", face = "plain"),
  # Set axis lines
  axis.line = element_line(color = "black", size = 0.5),
  # Set tick marks
  axis.ticks = element_line(color = "black", size = 0.5),
  # Set tick labels
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave('PCoA-16S.pdf', p, width =6, height = 5)




####(Fig. 1)PCoA_ITS######
# Load necessary packages
library(vegan)
library(ggplot2)
library(dplyr)
library(multcompView)

# Read OTU table data
otu_table <- read.csv("ado_All(1).csv", row.names = 1)

# Read metadata
metadata <- read.csv("group.csv")

# Calculate distance matrix using Bray-Curtis distance
distance_matrix <- vegdist(t(otu_table), method = "bray")

# Perform Principal Coordinate Analysis (PCoA), set eig = TRUE to return eigenvalues
pcoa_result <- cmdscale(distance_matrix, k = 2, eig = TRUE)

# Extract eigenvalues
eigenvalues <- pcoa_result$eig
print(eigenvalues)

# Calculate explained variance
explained_var_x <- eigenvalues[1] / sum(eigenvalues) * 100
explained_var_y <- eigenvalues[2] / sum(eigenvalues) * 100

# Create explained variance table
explained_var_table <- data.frame(
  Axis = c("PCoA1", "PCoA2"),
  Explained_Variance = c(explained_var_x, explained_var_y)
)

# Output explained variance table
print(explained_var_table)

# Optionally save the table as a CSV file
write.csv(explained_var_table, "pcoa_explained_variance.csv", row.names = FALSE)

# Extract PCoA scores
if (is.matrix(pcoa_result$points) || is.data.frame(pcoa_result$points)) {
  scores_df <- data.frame(PCoA1 = pcoa_result$points[, 1], PCoA2 = pcoa_result$points[, 2], metadata)
} else {
  stop("PCoA results are not a matrix or data frame; please check data and function calls.")
}

# Ensure Sites and Treatments are factor types
scores_df$Sites <- as.factor(scores_df$Sites)
scores_df$Treatments <- as.factor(scores_df$Treatments)

# Calculate centroids and standard deviations for each site and treatment
centroids <- scores_df %>%
  group_by(Sites, Treatments) %>%
  summarise(PCoA1_mean = mean(PCoA1), PCoA2_mean = mean(PCoA2),
            PCoA1_sd = sd(PCoA1), PCoA2_sd = sd(PCoA2))

# Custom colors and shapes
Treatments_colors <- c("MC-I" = "#f8caaa", "CP-I" = "#f09694", "MM-I" = "#a3c9dc", "NP-I" = "#acd16b", "MN-I" = "#89cbbf")
Sites_shapes <- c("S1" = 15, "S2" = 16, "S3" = 17, "S4" = 0, "S5" = 18, "S6" = 20)

# Adjust error bar thickness, set to 1 here
errorbar_size <- 0.5

# Plot centroids with error bars, using colors to distinguish treatments and shapes for sites
p1 <- ggplot(centroids, aes(x = PCoA1_mean, y = PCoA2_mean, color = Treatments, shape = Sites)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = PCoA2_mean - PCoA2_sd, ymax = PCoA2_mean + PCoA2_sd), width = 0.02) +
  geom_errorbarh(aes(xmin = PCoA1_mean - PCoA1_sd, xmax = PCoA1_mean + PCoA1_sd), height = 0.02) +
  scale_color_manual(values = Treatments_colors) +
  scale_shape_manual(values = Sites_shapes) +
  labs(x = paste0("PCoA1 (", round(explained_var_x, 2), "%)"), 
       y = paste0("PCoA2 (", round(explained_var_y, 2), "%)"), 
       title = "(b)Fungi") +
  theme_minimal()

# Add background ellipses for samples from the same site
p <- p1 + stat_ellipse(data = scores_df, aes(x = PCoA1, y = PCoA2, group = Sites, color = Sites), 
                       level = 0.95, linetype = 2, alpha = 0.2)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black", face = "plain"),
  axis.title.y = element_text(size = 12, color = "black", face = "plain"),
  # Set axis lines
  axis.line = element_line(color = "black", size = 0.5),
  # Set tick marks
  axis.ticks = element_line(color = "black", size = 0.5),
  # Set tick labels
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave('PCoA-ITS.pdf', p, width =6, height = 5)






####(Fig. 1e)####
library(ggcor)
library(ggplot2)
library(RColorBrewer)

spec <- t(read.table( "otu_3.csv", sep = ",", header = T, row.names = 1, check.names = F))
env <- read.table( "env_e3_3.csv", sep = ",", header = T, row.names = 1, check.names = F)
head(env)
head(spec)

df <- mantel_test(spec, env,spec.select =list(Prokaryoticcc=1:47413, Fungalcc= 47414:64905))

df <- df %>% 
  mutate(lty = cut(r, breaks = c(-Inf, 0, Inf), 
                   labels = c("r <= 0", "r > 0")),
         col = cut(p.value, breaks = c(0, 0.01, 0.05, 1),
                   labels = c("< 0.01", "0.01-0.05", ">= 0.05"),
                   right = FALSE, include.lowest = TRUE))

options(ggcor.link.inherit.aes = FALSE)
p <- quickcor(env, type = "upper", show.diag =FALSE) + geom_circle2() +
  anno_link(aes(colour = col, size = lty), data = df,curvature=0.2) +
  scale_size_manual(values = c(0.5, 1, 2)) +
  scale_colour_manual(values = c("#ED7D31", "#4472C4", "grey")) +
  guides(size = guide_legend(title = "Mantel's r",
                             override.aes = list(colour = "grey35"),order = 2),
         colour = guide_legend(title = "Mantel's p", 
                               override.aes = list(size = 3),order = 1),
         fill = guide_colorbar(title = "Pearson's r", order = 3)) +
  expand_axis(x = -6)+
  scale_fill_gradientn(colours = rev(brewer.pal(9, "RdBu")))

p
ggsave('ggcor_3.pdf',p, width = 6.5, height = 5)







####(Fig. 1)pH####
phi<-read.csv("e3_pH.csv", header=TRUE)

compare_means(pH~Group, data=phi, group.by = "site",method = "kruskal.test")

library(ggplot2)
phi$Group <- factor(phi$Group,levels=c("CP","MM","NP"))
p2 <- ggbarplot(phi, x="site", y="pH", add = "mean_se",color = "black",fill = "Group",ylim = c(0, 7.5),
                palette = c("#FB9A99","#A6CEE3","#B3DE69"), position = position_dodge(0.8))+
  stat_compare_means(aes(group=Group), label = "p.signif", label.y = 7, size = 10)+
  scale_y_continuous(name= expression(pH))+
  scale_x_discrete(name=expression(Sites))+
  theme(panel.background = element_rect(fill = "transparent", colour = "black"))+
  theme(axis.text.y  = element_text(size = 20,color="black"))+
  theme(axis.title.y = element_text(size = 20, color="black"))+
  theme(axis.title.x = element_text(size = 20, color="black"))+
  theme(legend.text=element_text(size=20, color="black"))+
  theme(axis.text.x = element_text(size = 20,color="black",vjust = 1.0, hjust = 0.55))+
  guides(fill=guide_legend(title=NULL))
p2

ggsave('pH_e3.pdf', p2, width = 6.5, height = 5)




####(Fig. S3)Abundance_16S####
# Load necessary packages
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)
library(writexl)

# Read data
data <- read.csv('qPCR_16S.csv')
# Group by site and treatment, calculate mean and standard deviation of abundance values for each treatment
grouped_data <- data %>%
  group_by(Site, Treatment) %>%
  summarise(
    average_abundance = mean(Abundance, na.rm = TRUE),
    sd_abundance = sd(Abundance, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- data %>%
  group_by(Site) %>%
  do({
    anova_result <- aov(Abundance ~ Treatment, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Site = unique(.$Site), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Site")

# Export significance analysis results to Excel
write_xlsx(significance_results, "16S_abundance_significance_results.xlsx")

# Custom colors
Treatment_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

# Draw bar plot to show average abundance values under different sites and treatments
p <- ggplot(grouped_data, aes(x = Site, y = average_abundance, fill = Treatment)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Abundance') +
  scale_fill_manual(values = Treatment_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_abundance - sd_abundance, ymax = average_abundance + sd_abundance),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

# Calculate fixed y-coordinate position to ensure significance markers are at the top
max_y <- max(grouped_data$average_abundance + grouped_data$sd_abundance)
y_position <- max_y + 3 * (max_y - min(grouped_data$average_abundance))

# Add significance markers
p <- p + geom_text(data = significance_results, aes(x = Site, y = max(grouped_data$average_abundance) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles and add full border
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black"),
  panel.border = element_rect(color = "black", fill = NA, linewidth = 0.5)
)+
  ylim(0,15)

print(p)    
ggsave("16S_Abundance.pdf", plot = p, width = 10, height = 6)




####(Fig. S3)Abundance_ITS####
# Load necessary packages
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)
library(writexl)

# Read data
data <- read.csv('qPCR_ITS.csv')
# Group by site and treatment, calculate mean and standard deviation of abundance values for each treatment
grouped_data <- data %>%
  group_by(Site, Treatment) %>%
  summarise(
    average_abundance = mean(Abundance, na.rm = TRUE),
    sd_abundance = sd(Abundance, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- data %>%
  group_by(Site) %>%
  do({
    anova_result <- aov(Abundance ~ Treatment, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Site = unique(.$Site), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Site")

# Export significance analysis results to Excel
write_xlsx(significance_results, "ITS_abundance_significance_results.xlsx")

# Custom colors
Treatment_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

# Draw bar plot to show average abundance values under different sites and treatments
p <- ggplot(grouped_data, aes(x = Site, y = average_abundance, fill = Treatment)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Abundance') +
  scale_fill_manual(values = Treatment_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_abundance - sd_abundance, ymax = average_abundance + sd_abundance),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

# Calculate fixed y-coordinate position to ensure significance markers are at the top
max_y <- max(grouped_data$average_abundance + grouped_data$sd_abundance)
y_position <- max_y + 3 * (max_y - min(grouped_data$average_abundance))

# Add significance markers
p <- p + geom_text(data = significance_results, aes(x = Site, y = max(grouped_data$average_abundance) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles and add full border
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black"),
  panel.border = element_rect(color = "black", fill = NA, linewidth = 0.5)
)+
  ylim(0,15)

print(p)    
ggsave("ITS_Abundance.pdf", plot = p, width = 10, height = 6)




####(Fig. S3)Richness_16S####
# Load required packages
library(vegan)
library(ggplot2)
library(ggpubr)
library(ggsci)
library(Cairo)
library(showtext)
library(dplyr)

# Read OTU data
otu <- read.csv("16S_OTU.csv", row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)
otu <- t(otu)
otu <- otu[1:120, ]

# Calculate richness
richness <- rowSums(otu > 0)
write.csv(richness, "16S_richness.csv", quote = FALSE)

# Assume the grouping information file is named group_info.csv, containing three columns: Sample, Site, Treatment
group_info <- read.csv("richness_group.csv")

# Merge richness data with grouping information
data <- data.frame(Sample = names(richness), Richness = richness)
data <- merge(data, group_info, by = "Sample")

# Group by site and treatment, calculate mean and standard deviation
grouped_data <- data %>%
  group_by(Site, Treatment) %>%
  summarise(
    mean_richness = mean(Richness),
    sd_richness = sd(Richness)
  )

# Perform one-way ANOVA by site and add significance markers
significance_results <- data %>%
  group_by(Site) %>%
  do({
    anova_result <- aov(Richness ~ Treatment, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Site = unique(.$Site), significance = significance)
  })


# Custom treatment colors, there are 5 treatments here, you can modify the color values
Treatment_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

# Draw bar plot
p1 <- ggplot(grouped_data, aes(x = factor(Site), y = mean_richness, fill = factor(Treatment))) +
  geom_col(position = position_dodge(width = 0.9), color = "black") +
  geom_errorbar(aes(ymin = mean_richness - sd_richness, ymax = mean_richness + sd_richness),
                position = position_dodge(width = 0.9), width = 0.2, color = "black") +
  scale_fill_manual(values = Treatment_colors) +
  scale_color_manual(values = rep("black", length(Treatment_colors))) +
  labs(x = "Sites", y = "Bacterial richness") +
  theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent')) +
  theme(legend.key = element_rect(fill = 'transparent'), legend.title = element_blank()) +
  # Add significance markers
  geom_text(data = significance_results, aes(x = Site, y = max(grouped_data$mean_richness) + 1, label = significance), 
            inherit.aes = FALSE, vjust = 0, size = 5)

print(p1)
ggsave('16S_richness(ZHU).pdf', p1, width = 10, height = 6)




####(Fig. S3)Richness_ITS####
# Load required packages
library(vegan)
library(ggplot2)
library(ggpubr)
library(ggsci)
library(Cairo)
library(showtext)
library(dplyr)

# Read OTU data
otu <- read.csv("ITS_OTU.csv", row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)
otu <- t(otu)
otu <- otu[1:120, ]

# Calculate richness
richness <- rowSums(otu > 0)
write.csv(richness, "ITS_richness.csv", quote = FALSE)

# Assume the grouping information file is named group_info.csv, containing three columns: Sample, Site, Treatment
group_info <- read.csv("richness_group.csv")

# Merge richness data with grouping information
data <- data.frame(Sample = names(richness), Richness = richness)
data <- merge(data, group_info, by = "Sample")

# Group by site and treatment, calculate mean and standard deviation
grouped_data <- data %>%
  group_by(Site, Treatment) %>%
  summarise(
    mean_richness = mean(Richness),
    sd_richness = sd(Richness)
  )

# Perform one-way ANOVA by site and add significance markers
significance_results <- data %>%
  group_by(Site) %>%
  do({
    anova_result <- aov(Richness ~ Treatment, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Site = unique(.$Site), significance = significance)
  })


# Custom treatment colors, there are 5 treatments here, you can modify the color values
Treatment_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

# Draw bar plot
p1 <- ggplot(grouped_data, aes(x = factor(Site), y = mean_richness, fill = factor(Treatment))) +
  geom_col(position = position_dodge(width = 0.9), color = "black") +
  geom_errorbar(aes(ymin = mean_richness - sd_richness, ymax = mean_richness + sd_richness),
                position = position_dodge(width = 0.9), width = 0.2, color = "black") +
  scale_fill_manual(values = Treatment_colors) +
  scale_color_manual(values = rep("black", length(Treatment_colors))) +
  labs(x = "Sites", y = "Fungal richness") +
  theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent')) +
  theme(legend.key = element_rect(fill = 'transparent'), legend.title = element_blank()) +
  # Add significance markers
  geom_text(data = significance_results, aes(x = Site, y = max(grouped_data$mean_richness) + 1, label = significance), 
            inherit.aes = FALSE, vjust = 0, size = 5)

print(p1)
ggsave('ITS_richness(ZHU).pdf', p1, width = 10, height = 6)




####(Fig. S5)Bray-Curtis similarity_16S#####
##Data processing##
library(ggpubr)
library(ggplot2)
library(geosphere)
library(cluster)
library(gclus)
library(vegan)
library(gridExtra)
library(ggsignif)
library(agricolae)
spe <- read.csv('S1_C-CP.csv',  row.names = 1, check.names = FALSE)
spe <- (spe/colSums(spe)[1])^0.5
spe <- data.frame(t(spe))
comm_sim <- 1-as.matrix(vegan::vegdist(spe, method = 'bray'))
head(comm_sim)
diag(comm_sim) <- 0  #Remove diagonal values from the community similarity matrix (self-similarity of samples)
comm_sim[upper.tri(comm_sim)] <- 0  #Community similarity matrix is symmetric, so only select values from half the triangle (e.g., lower triangle)
comm_sim <- reshape2::melt(comm_sim)
comm_sim <- subset(comm_sim, value != 0)
head(comm_sim)
write.csv(comm_sim,"Commsim_S1_C-CP.csv",quote = FALSE)

##Plotting##
phi<-read.csv("Commsim_16S.csv",header = TRUE)
# Calculate mean of the 'number' column
mean_value <- mean(phi$number)
print(paste("Mean value of the 'number' column in the data:", mean_value))
compare_means(number~group,data=phi,group.by="treat")
library(ggplot2)
p<-ggbarplot(phi,x="treat",y="number",add="mean_se",color="black",fill="group",
             palette=c("#99badf","#df9e9b","#9dcfb6","#f8caaa", "#f09694","#a3c9dc"),position=position_dodge(0.8))+
  stat_compare_means(aes(group=group),label="p.signif",label.y=1,size=10)+
  theme(panel.background = element_rect(fill = "transparent", colour = "black"))+ #Add black border
  theme(axis.text.y  = element_text(size = 12,color="black"))+##Set font size for y-axis ticks
  theme(axis.title.y = element_text(size = 12, color="black"))+#Set y-axis title size
  theme(axis.title.x = element_text(size = 12, color="black"))+#Set x-axis title size
  theme(legend.text=element_text(size=12, color="black"))+#Legend font size
  theme(axis.text.x = element_text(size = 12,color="black"))+##Set font size for x-axis ticks
  labs(x=NULL,y="Bacterial similarity")+
  annotate("text", x = mean(as.numeric(factor(phi$treat))), y = max(phi$number, na.rm = TRUE) * 1.1, 
           label = paste("Mean: ", round(mean_value, 4)), size = 5)# Add mean annotation at the top of the plot
p
ggsave('commsim_16S.pdf', p, width = 8, height = 5)




####(Fig. S5)Bray-Curtis similarity_ITS#####
##Data processing##
library(ggpubr)
library(ggplot2)
library(geosphere)
library(cluster)
library(gclus)
library(vegan)
library(gridExtra)
library(ggsignif)
library(agricolae)
spe <- read.csv('S1_C-CP.csv',  row.names = 1, check.names = FALSE)
spe <- (spe/colSums(spe)[1])^0.5
spe <- data.frame(t(spe))
comm_sim <- 1-as.matrix(vegan::vegdist(spe, method = 'bray'))
head(comm_sim)
diag(comm_sim) <- 0  #Remove diagonal values from the community similarity matrix (self-similarity of samples)
comm_sim[upper.tri(comm_sim)] <- 0  #Community similarity matrix is symmetric, so only select values from half the triangle (e.g., lower triangle)
comm_sim <- reshape2::melt(comm_sim)
comm_sim <- subset(comm_sim, value != 0)
head(comm_sim)
write.csv(comm_sim,"Commsim_S1_C-CP.csv",quote = FALSE)

##Plotting##
phi<-read.csv("Commsim_ITS.csv",header = TRUE)
# Calculate mean of the 'number' column
mean_value <- mean(phi$number)
print(paste("Mean value of the 'number' column in the data:", mean_value))
compare_means(number~group,data=phi,group.by="treat")
library(ggplot2)
p<-ggbarplot(phi,x="treat",y="number",add="mean_se",color="black",fill="group",
             palette=c("#99badf","#df9e9b","#9dcfb6","#f8caaa", "#f09694","#a3c9dc"),position=position_dodge(0.8))+
  stat_compare_means(aes(group=group),label="p.signif",label.y=1,size=10)+
  theme(panel.background = element_rect(fill = "transparent", colour = "black"))+ #Add black border
  theme(axis.text.y  = element_text(size = 12,color="black"))+##Set font size for y-axis ticks
  theme(axis.title.y = element_text(size = 12, color="black"))+#Set y-axis title size
  theme(axis.title.x = element_text(size = 12, color="black"))+#Set x-axis title size
  theme(legend.text=element_text(size=12, color="black"))+#Legend font size
  theme(axis.text.x = element_text(size = 12,color="black"))+##Set font size for x-axis ticks
  labs(x=NULL,y="Fungal similarity")+
  annotate("text", x = mean(as.numeric(factor(phi$treat))), y = max(phi$number, na.rm = TRUE) * 1.1, 
           label = paste("Mean: ", round(mean_value, 4)), size = 5)# Add mean annotation at the top of the plot
p
ggsave('commsim_ITS.pdf', p, width = 8, height = 5)




####(Fig. S6_16S)####
bac <- read.csv("16S_s1.csv", header = TRUE, row.names = 1)
group <- read.csv("group_s1.csv", header = FALSE)
bac1 <- t(bac[,1:ncol(bac)])

library(betapart)
library(reshape2)
library(dplyr)
group$V2 <- factor(group$V2)
beta.bac.w <- c()
for (i in 1:length(levels(group$V2))) {
  bac.w <- bac1[rownames(bac1) %in% group$V1[group$V2 == levels(group$V2)[i]],]
  bac.w[bac.w > 0] = 1
  beta.w <- betapart.core.abund(bac.w)
  bac.w.jac <- beta.pair.abund(beta.w)
  bac.w.turn <- as.matrix(bac.w.jac$beta.bray.bal)
  bac.w.turn[lower.tri(bac.w.turn)] = 0
  bac.w.turn <- melt(bac.w.turn)
  bac.w.turn <- bac.w.turn[bac.w.turn$value > 0,]
  
  bac.w.nest <- as.matrix(bac.w.jac$beta.bray.gra)
  bac.w.nest[lower.tri(bac.w.nest)] = 0
  bac.w.nest <- melt(bac.w.nest)
  bac.w.nest <- bac.w.nest[bac.w.nest$value > 0,]
  
  bac.w <- rbind(bac.w.turn,bac.w.nest)
  bac.w$Type <- c(rep("Turnover",nrow(bac.w.turn)),rep("Nestedness",nrow(bac.w.nest)))
  bac.w$Group <- rep(levels(group$V2)[i],nrow(bac.w))
  beta.bac.w <- rbind(beta.bac.w,bac.w)
}

write.csv(beta.bac.w, file = "β_16S_s1.csv")

#----------------------box
library(vegan)
library(ggplot2)
library(ggpubr)
species <-read.csv("β_16S_all.csv", header=TRUE, row.names = 1)

scaleFUN<-  function(x) sprintf ("%.2f",x)
my_comparisons<-list(c("Turnover","Nestedness"))

p4 = ggplot(species,aes(x=factor(Group,level=c("Turnover","Nestedness")), y=richness,color = Group))+
  stat_boxplot(geom="errorbar",width=0.15)+
  geom_boxplot(alpha=0.7,aes(fill=Group))+
  geom_point()+
  scale_fill_manual(values = c("#7FC97F", "#BEAED4"))+
  scale_y_continuous(name= expression("Value among priority groups"),labels=scaleFUN)+
  scale_x_discrete(name=expression("Partitioning beta diversity of species abundances"))+
  scale_color_manual(values = c("#7FC97F", "#BEAED4"))+
  theme_bw()+
  theme(legend.position='none')+
  theme(panel.background = element_rect(fill = "white", colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        text = element_text(colour="black",size=20),
        axis.title = element_text(colour="black"),
        axis.text=element_text(colour="black",size=20),
        axis.title.x = element_blank(),
        axis.title.y = element_text(colour="black", size = 20))+
  theme(axis.text.x = element_text(size = 20,color="black"))+
  theme(axis.text.y  = element_text(size = 20,color="black"))+
  theme(axis.title.x  = element_text(size = 20, color="black"))+
  stat_compare_means(comparisons=my_comparisons,label ="p.signif",step_increase = 0.1,map_signif_level = T, method = "wilcox.test", paired = TRUE,size=7)+
  stat_compare_means(label.y = 0.85,label.x = 1.6,size=7,method = "wilcox.test",paired = TRUE) 

p4
ggsave('box_β_16S.pdf', p4, width = 7, height = 6)




####(Fig. S6_ITS)####
bac <- read.csv("ITS_s1.csv", header = TRUE, row.names = 1)
group <- read.csv("group_s1.csv", header = FALSE)
bac1 <- t(bac[,1:ncol(bac)])

library(betapart)
library(reshape2)
library(dplyr)
group$V2 <- factor(group$V2)
beta.bac.w <- c()
for (i in 1:length(levels(group$V2))) {
  bac.w <- bac1[rownames(bac1) %in% group$V1[group$V2 == levels(group$V2)[i]],]
  bac.w[bac.w > 0] = 1
  beta.w <- betapart.core.abund(bac.w)
  bac.w.jac <- beta.pair.abund(beta.w)
  bac.w.turn <- as.matrix(bac.w.jac$beta.bray.bal)
  bac.w.turn[lower.tri(bac.w.turn)] = 0
  bac.w.turn <- melt(bac.w.turn)
  bac.w.turn <- bac.w.turn[bac.w.turn$value > 0,]
  
  bac.w.nest <- as.matrix(bac.w.jac$beta.bray.gra)
  bac.w.nest[lower.tri(bac.w.nest)] = 0
  bac.w.nest <- melt(bac.w.nest)
  bac.w.nest <- bac.w.nest[bac.w.nest$value > 0,]
  
  bac.w <- rbind(bac.w.turn,bac.w.nest)
  bac.w$Type <- c(rep("Turnover",nrow(bac.w.turn)),rep("Nestedness",nrow(bac.w.nest)))
  bac.w$Group <- rep(levels(group$V2)[i],nrow(bac.w))
  beta.bac.w <- rbind(beta.bac.w,bac.w)
}

write.csv(beta.bac.w, file = "β_ITS_s1.csv")

#----------------------box
library(vegan)
library(ggplot2)
library(ggpubr)
species <-read.csv("β_ITS_all.csv", header=TRUE, row.names = 1)

scaleFUN<-  function(x) sprintf ("%.2f",x)
my_comparisons<-list(c("Turnover","Nestedness"))

p4 = ggplot(species,aes(x=factor(Group,level=c("Turnover","Nestedness")), y=richness,color = Group))+
  stat_boxplot(geom="errorbar",width=0.15)+
  geom_boxplot(alpha=0.7,aes(fill=Group))+
  geom_point()+
  scale_fill_manual(values = c("#7FC97F", "#BEAED4"))+
  scale_y_continuous(name= expression("Value among priority groups"),labels=scaleFUN)+
  scale_x_discrete(name=expression("Partitioning beta diversity of species abundances"))+
  scale_color_manual(values = c("#7FC97F", "#BEAED4"))+
  theme_bw()+
  theme(legend.position='none')+
  theme(panel.background = element_rect(fill = "white", colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        text = element_text(colour="black",size=20),
        axis.title = element_text(colour="black"),
        axis.text=element_text(colour="black",size=20),
        axis.title.x = element_blank(),
        axis.title.y = element_text(colour="black", size = 20))+
  theme(axis.text.x = element_text(size = 20,color="black"))+
  theme(axis.text.y  = element_text(size = 20,color="black"))+
  theme(axis.title.x  = element_text(size = 20, color="black"))+
  stat_compare_means(comparisons=my_comparisons,label ="p.signif",step_increase = 0.1,map_signif_level = T, method = "wilcox.test", paired = TRUE,size=7)+
  stat_compare_means(label.y = 0.85,label.x = 1.6,size=7,method = "wilcox.test",paired = TRUE) 

p4
ggsave('box_β_ITS.pdf', p4, width = 7, height = 6)




####(Fig. S7)pH####
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)

# Check if the writexl package is installed; install it if not
if (!require(writexl)) {
  install.packages("writexl")
  library(writexl)
}

# Read data files
data <- read.csv('pH.csv')
grouping <- read.csv('group.csv')

# Merge data and grouping information
merged_data <- merge(data, grouping, by = "Samples")

# Group by sites and treatments, calculate the mean and standard deviation of Values for each treatment
grouped_data <- merged_data %>%
  group_by(Sites, Treatments) %>%
  summarise(
    average_Values = mean(Values, na.rm = TRUE),
    sd_Values = sd(Values, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- merged_data %>%
  group_by(Sites) %>%
  do({
    anova_result <- aov(Values ~ Treatments, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Sites = unique(.$Sites), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Sites")

# Export significance analysis results to Excel
write_xlsx(significance_results, "pH_significance_results.xlsx")

# Custom colors
Treatments_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

p <- ggplot(grouped_data, aes(x = Sites, y = average_Values, fill = Treatments)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Values') +
  scale_fill_manual(values = Treatments_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_Values - sd_Values, ymax = average_Values + sd_Values),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

p <- p + geom_text(data = significance_results, aes(x = Sites, y = max(grouped_data$average_Values) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave("pH.pdf", plot = p, width = 10, height = 6)




####(Fig. S7)Available potassium####
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)

# Check if the writexl package is installed; install it if not
if (!require(writexl)) {
  install.packages("writexl")
  library(writexl)
}

# Read data files
data <- read.csv('A_K.csv')
grouping <- read.csv('group.csv')

# Merge data and grouping information
merged_data <- merge(data, grouping, by = "Samples")

# Group by sites and treatments, calculate the mean and standard deviation of Values for each treatment
grouped_data <- merged_data %>%
  group_by(Sites, Treatments) %>%
  summarise(
    average_Values = mean(Values, na.rm = TRUE),
    sd_Values = sd(Values, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- merged_data %>%
  group_by(Sites) %>%
  do({
    anova_result <- aov(Values ~ Treatments, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Sites = unique(.$Sites), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Sites")

# Export significance analysis results to Excel
write_xlsx(significance_results, "A_K_significance_results.xlsx")

# Custom colors
Treatments_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

p <- ggplot(grouped_data, aes(x = Sites, y = average_Values, fill = Treatments)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Values') +
  scale_fill_manual(values = Treatments_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_Values - sd_Values, ymax = average_Values + sd_Values),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

p <- p + geom_text(data = significance_results, aes(x = Sites, y = max(grouped_data$average_Values) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave("A_K.pdf", plot = p, width = 10, height = 6)




####(Fig. S7)Available phosphorus####
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)

# Check if the writexl package is installed; install it if not
if (!require(writexl)) {
  install.packages("writexl")
  library(writexl)
}

# Read data files
data <- read.csv('A_P.csv')
grouping <- read.csv('group.csv')

# Merge data and grouping information
merged_data <- merge(data, grouping, by = "Samples")

# Group by sites and treatments, calculate the mean and standard deviation of Values for each treatment
grouped_data <- merged_data %>%
  group_by(Sites, Treatments) %>%
  summarise(
    average_Values = mean(Values, na.rm = TRUE),
    sd_Values = sd(Values, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- merged_data %>%
  group_by(Sites) %>%
  do({
    anova_result <- aov(Values ~ Treatments, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Sites = unique(.$Sites), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Sites")

# Export significance analysis results to Excel
write_xlsx(significance_results, "A_P_significance_results.xlsx")

# Custom colors
Treatments_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

p <- ggplot(grouped_data, aes(x = Sites, y = average_Values, fill = Treatments)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Values') +
  scale_fill_manual(values = Treatments_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_Values - sd_Values, ymax = average_Values + sd_Values),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

p <- p + geom_text(data = significance_results, aes(x = Sites, y = max(grouped_data$average_Values) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave("A_P.pdf", plot = p, width = 10, height = 6)




####(Fig. S7)Ammonium nitrogen####
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)

# Check if the writexl package is installed; install it if not
if (!require(writexl)) {
  install.packages("writexl")
  library(writexl)
}

# Read data files
data <- read.csv('a_n.csv')
grouping <- read.csv('group.csv')

# Merge data and grouping information
merged_data <- merge(data, grouping, by = "Samples")

# Group by sites and treatments, calculate the mean and standard deviation of Values for each treatment
grouped_data <- merged_data %>%
  group_by(Sites, Treatments) %>%
  summarise(
    average_Values = mean(Values, na.rm = TRUE),
    sd_Values = sd(Values, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- merged_data %>%
  group_by(Sites) %>%
  do({
    anova_result <- aov(Values ~ Treatments, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Sites = unique(.$Sites), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Sites")

# Export significance analysis results to Excel
write_xlsx(significance_results, "a_n_significance_results.xlsx")

# Custom colors
Treatments_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

p <- ggplot(grouped_data, aes(x = Sites, y = average_Values, fill = Treatments)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Values') +
  scale_fill_manual(values = Treatments_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_Values - sd_Values, ymax = average_Values + sd_Values),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

p <- p + geom_text(data = significance_results, aes(x = Sites, y = max(grouped_data$average_Values) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave("a_n.pdf", plot = p, width = 10, height = 6)




####(Fig. S7)Nitrate nitrogen####
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)

# Check if the writexl package is installed; install it if not
if (!require(writexl)) {
  install.packages("writexl")
  library(writexl)
}

# Read data files
data <- read.csv('n_n.csv')
grouping <- read.csv('group.csv')

# Merge data and grouping information
merged_data <- merge(data, grouping, by = "Samples")

# Group by sites and treatments, calculate the mean and standard deviation of Values for each treatment
grouped_data <- merged_data %>%
  group_by(Sites, Treatments) %>%
  summarise(
    average_Values = mean(Values, na.rm = TRUE),
    sd_Values = sd(Values, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- merged_data %>%
  group_by(Sites) %>%
  do({
    anova_result <- aov(Values ~ Treatments, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Sites = unique(.$Sites), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Sites")

# Export significance analysis results to Excel
write_xlsx(significance_results, "n_n_significance_results.xlsx")

# Custom colors
Treatments_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

p <- ggplot(grouped_data, aes(x = Sites, y = average_Values, fill = Treatments)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Values') +
  scale_fill_manual(values = Treatments_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_Values - sd_Values, ymax = average_Values + sd_Values),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

p <- p + geom_text(data = significance_results, aes(x = Sites, y = max(grouped_data$average_Values) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave("n_n.pdf", plot = p, width = 10, height = 6)




####(Fig. S7)Soil total organic####
library(ggplot2)
library(dplyr)
library(tidyr)
library(agricolae)

# Check if the writexl package is installed; install it if not
if (!require(writexl)) {
  install.packages("writexl")
  library(writexl)
}

# Read data files
data <- read.csv('TOC.csv')
grouping <- read.csv('group.csv')

# Merge data and grouping information
merged_data <- merge(data, grouping, by = "Samples")

# Group by location and treatment, calculate mean and standard deviation of Values
grouped_data <- merged_data %>%
  group_by(Sites, Treatments) %>%
  summarise(
    average_Values = mean(Values, na.rm = TRUE),
    sd_Values = sd(Values, na.rm = TRUE)
  )

# Perform one-way ANOVA and add significance markers
significance_results <- merged_data %>%
  group_by(Sites) %>%
  do({
    anova_result <- aov(Values ~ Treatments, data = .)
    p_value <- summary(anova_result)[[1]][["Pr(>F)"]][1]
    if (p_value < 0.001) {
      significance <- "***"
    } else if (p_value < 0.01) {
      significance <- "**"
    } else if (p_value < 0.05) {
      significance <- "*"
    } else {
      significance <- "ns"
    }
    data.frame(Sites = unique(.$Sites), significance = significance)
  })

# Merge significance results into grouped data
grouped_data <- left_join(grouped_data, significance_results, by = "Sites")

# Export significance analysis results to Excel
write_xlsx(significance_results, "TOC_significance_results.xlsx")

# Custom colors
Treatments_colors <- c("C" = "#f8caaa", "CP" = "#f09694", "S" = "#a3c9dc", "NP" = "#acd16b", "N" = "#89cbbf")

p <- ggplot(grouped_data, aes(x = Sites, y = average_Values, fill = Treatments)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.8, color = "black") + 
  labs(x = 'Sites',
       y = 'Values') +
  scale_fill_manual(values = Treatments_colors) +
  scale_x_discrete(expand = expansion(mult = c(0.12, 0.12))) + 
  theme_minimal()

# Add error bars
p <- p + geom_errorbar(
  aes(ymin = average_Values - sd_Values, ymax = average_Values + sd_Values),
  position = position_dodge(width = 0.8),
  width = 0.2,
  color = "black"
)

p <- p + geom_text(data = significance_results, aes(x = Sites, y = max(grouped_data$average_Values) + 0.1, label = significance), 
                   inherit.aes = FALSE, vjust = 0, size = 5)

# Set axis label styles
p <- p + theme(
  axis.title.x = element_text(size = 12, color = "black"),
  axis.title.y = element_text(size = 12, color = "black"),
  axis.line = element_line(color = "black", linewidth = 0.5),
  axis.ticks = element_line(color = "black", linewidth = 0.5),
  axis.text.x = element_text(size = 10, color = "black"),
  axis.text.y = element_text(size = 10, color = "black")
)

print(p)
ggsave("TOC.pdf", plot = p, width = 10, height = 6)




